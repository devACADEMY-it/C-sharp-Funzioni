﻿/*
Scrivere un programma che visualizzi la cartella "documenti"
in console come da esempio nel file screenshot.png

- Creare un programma dinamico,
  che cioè si adatti alla struttura delle cartelle nel momento in cui le modifichiamo
  senza che sia necessario riscrivere il programma
- Cercate di utlizzare delle funzioni per parti del programma che si ripetono.
- Le cartelle devono essere visualizzte con un colore diverso dai files.
- I files modificati da meno di 5 minuti devono assumere un colore diverso
- I files modificati da meno di 30 minuti (ma da più di 5) devono assumere un colore ancora diverso
*/