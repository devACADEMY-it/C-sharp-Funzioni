﻿/*
Scrivere un programma che visualizzi la cartella "documenti"
in console come da esempio nel file screenshot.png

- Creare un programma dinamico,
  che cioè si adatti alla struttura delle cartelle nel momento in cui le modifichiamo
  senza che sia necessario riscrivere il programma
- Cercate di utlizzare delle funzioni per parti del programma che si ripetono.
- Le cartelle devono essere visualizzte con un colore diverso dai files.
- I files modificati da meno di 5 minuti devono assumere un colore diverso
- I files modificati da meno di 30 minuti (ma da più di 5) devono assumere un colore ancora diverso
*/


var root = new DirectoryInfo("documenti");
DateTime oggi = DateTime.Now;

void Esamina(System.IO.DirectoryInfo dir, int livello)
{
    System.IO.FileInfo[]? files = null;
    System.IO.DirectoryInfo[]? subDirs = null;

    LogDirectory(dir, livello);

    // cerco le sottodirectory
    subDirs = dir.GetDirectories();
    foreach (System.IO.DirectoryInfo dirInfo in subDirs)
    {
        Esamina(dirInfo, livello + 1);
    }

    // cerco i files
    files = dir.GetFiles("*.*");
    foreach (System.IO.FileInfo fi in files)
    {
        LogFile(fi, livello + 1);
    }
}

void LogDirectory(System.IO.DirectoryInfo dirInfo, int livello)
{
    Console.ForegroundColor = ConsoleColor.DarkGreen;
    Console.WriteLine($"{GetSeparatore(livello)}{dirInfo.Name}");
    Console.ResetColor();
}

void LogFile(System.IO.FileInfo fi, int livello)
{
    var t = oggi.Subtract(fi.LastWriteTime).TotalMinutes; // tempoPassatoUltimaModifica
    var dataModifica = $"({Math.Floor(t)} minuti fa)";

    if (t < 5)
    {
        Console.ForegroundColor = ConsoleColor.Magenta;
    }
    else if (t < 30)
    {
        Console.ForegroundColor = ConsoleColor.DarkYellow;
    }
    Console.WriteLine($"{GetSeparatore(livello)}{fi.Name} {dataModifica}");
    Console.ResetColor();
}

string GetSeparatore(int livello)
{
    string retVal = "";
    for (int i = 0; i < livello; i++)
    {
        retVal += "|   ";
    }

    retVal += "|-- ";

    return retVal;
}

Esamina(root, 0);