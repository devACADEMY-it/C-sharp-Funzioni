﻿using System.Globalization;

void LogTitolo(string titolo)
{
    Console.WriteLine("");
    Console.ForegroundColor = ConsoleColor.DarkGreen;
    Console.WriteLine(titolo + ":");
    Console.ResetColor();
}

// 06-01 DATETIME E TIMESPAN
var oggi = DateTime.Now;
LogTitolo("Data di oggi");
Console.WriteLine(oggi);

var ora = oggi.TimeOfDay;
LogTitolo("Orario");
Console.WriteLine(ora);

// creare una nuova data
var scopertaAmerica = new DateTime(1492, 10, 12);
var durata = new TimeSpan(23, 16, 0);
// var durata = new TimeSpan(25, 16, 0); // è una durata, un lasso di tempo, non una rappresentazione dell'ora
var durata2 = TimeSpan.FromMinutes(123);

scopertaAmerica = scopertaAmerica.Add(durata);
LogTitolo("Data e ora scoperta America");
Console.WriteLine(scopertaAmerica);

// 06-02 DATETIMEOFFSET
// DateTimeOffset = Date + Time + Offset (fuso orario, distanziamento dal fuso 0 UTC (Universal Coordinated Time))

LogTitolo("Data OffSet UTC");
var oggiUTC = DateTimeOffset.UtcNow;
Console.WriteLine(oggiUTC + " <= UTC con Offset");
Console.WriteLine(oggiUTC.DateTime + " <= DateTime senza Offset");
Console.WriteLine(oggiUTC.LocalDateTime + " <= DateTime senza Offset Italia");
Console.WriteLine(oggiUTC.UtcDateTime + " <= DateTime senza Offset UTC");
Console.WriteLine(oggiUTC.Offset + " <= Valore Offset");

LogTitolo("Data OffSet Italia");
var oggiItalia = DateTimeOffset.Now;
Console.WriteLine(oggiItalia + " <= UTC con Offset");
Console.WriteLine(oggiItalia.DateTime + " <= DateTime senza Offset");
Console.WriteLine(oggiItalia.LocalDateTime + " <= DateTime senza Offset Italia");
Console.WriteLine(oggiItalia.UtcDateTime + " <= DateTime senza Offset UTC");
Console.WriteLine(oggiItalia.Offset + " <= Valore Offset");

// 06-03 EPOCH
LogTitolo("Epoch => Numero di secondi/millisecondi passati dal 1/1/1970 00:00:00");
var epoch = DateTimeOffset.FromUnixTimeSeconds(1646727981);
Console.WriteLine(epoch);
Console.WriteLine(epoch.LocalDateTime);
Console.WriteLine(oggiUTC.ToUnixTimeSeconds());
Console.WriteLine(((DateTimeOffset)scopertaAmerica).ToUnixTimeSeconds());

// 06-04 FORMATTAZIONE
LogTitolo("DateTime, rappresentazione in stringa");
Console.WriteLine(oggi.ToString());
Console.WriteLine(oggi.ToShortDateString() + " <= Short Date");
Console.WriteLine(oggi.ToLongDateString() + " <= Long Date");
Console.WriteLine(oggi.ToShortTimeString() + " <= Short Time");
Console.WriteLine(oggi.ToLongTimeString() + " <= Long Time");
Console.WriteLine(oggi.ToString("dddd, dd MMMM yyyy HH:mm") + " <= Custom"); // vedi riferimenti note del docente
Console.WriteLine(oggi.ToString(new CultureInfo("en-EN")) + " <= ToString() Inglese");
Console.WriteLine(oggi.ToString("dddd, dd MMMM yyyy HH:mm", new CultureInfo("en-EN")) + " <= Custom Inglese");

// 06-05 PARSING
LogTitolo("DateTime conversione da stringa");
CultureInfo culture = new CultureInfo("en-US");

DateTime d = DateTime.Parse("10/22/2015 12:10:15 PM", culture);
d = DateTime.ParseExact("10-22-2015", "MM-dd-yyyy", culture); // 10/22/2015 12:00:00 AM  
Console.WriteLine(d);

bool isSuccess = DateTime.TryParse("10-22-2015", out d); // False  
Console.WriteLine("TryParse Inglese (server in Italiano)");
Console.WriteLine(isSuccess);
Console.WriteLine(d);
Console.WriteLine("");

Console.WriteLine("TryParse Italiano (server in Italiano)");
isSuccess = DateTime.TryParse("22/10/2015", out d); // True  
Console.WriteLine(isSuccess);
Console.WriteLine(d);
Console.WriteLine("");

CultureInfo provider = CultureInfo.InvariantCulture; // non dipende dalle impostazioni del server
isSuccess = DateTime.TryParseExact("10-22-2015", "MM-dd-yyyy", provider, DateTimeStyles.None, out d); // True  
Console.WriteLine(isSuccess);
Console.WriteLine(d);


// 06-06 COMPONENTI DELLE DATE
LogTitolo("Componenti dell'oggetto DateTime");
Console.WriteLine(oggi.Date + " <= solo data");
Console.WriteLine(oggi.TimeOfDay + " <= solo ora"); // timespan
Console.WriteLine(oggi.DayOfWeek + " <= giorno della settimana (enum)");
Console.WriteLine((oggi.DayOfWeek == DayOfWeek.Friday) + " <= oggi è Venerdì?");
Console.WriteLine(oggi.DayOfYear + " <= giorno dell'anno");
Console.WriteLine(oggi.Day + " <= giorno del mese");
Console.WriteLine(oggi.Month + " <= mese");
Console.WriteLine(oggi.Year + " <= anno");
Console.WriteLine(oggi.Hour + " <= ore");
Console.WriteLine(oggi.Minute + " <= minuti");
Console.WriteLine(oggi.Second + " <= secondi");
Console.WriteLine(oggi.TimeOfDay.TotalMinutes + " <= minuti totali di un TimeSpan"); // usato per conteggiare minuti di un determinato lasso di tempo
Console.WriteLine(oggi.TimeOfDay.TotalDays + " <= giorni totali di un TimeSpan"); // usato per conteggiare minuti di un determinato lasso di tempo

// 06-07 AGGIUNTA E SOTTRAZIONE DI DATE
var dataPleasePleaseMe = new DateTime(1963, 3, 22);
var dataLetItBe = new DateTime(1970, 5, 8);

// somma
// sottrazione
LogTitolo("Operazioni sulle date");
Console.WriteLine(dataPleasePleaseMe + " <= data rilascio");
Console.WriteLine(dataPleasePleaseMe.Add(new TimeSpan(3, 0, 0)) + " <= aggiunge timespan di 3 ore");
var treOre = new TimeSpan(3, 0, 0);
Console.WriteLine((dataPleasePleaseMe + treOre) + " <= aggiunge timespan di 3 ore (equivalente)");
Console.WriteLine(dataPleasePleaseMe.Add(-new TimeSpan(3, 0, 0)) + " <= toglie timespan di 3 ore");
Console.WriteLine(dataPleasePleaseMe.AddDays(5) + " <= aggiunge 5 giorni");
Console.WriteLine(dataPleasePleaseMe.AddDays(-5) + " <= toglie 5 giorni");
// ALTRI ADD come AddDays

var tempoPassato = dataLetItBe - dataPleasePleaseMe;
tempoPassato = dataLetItBe.Subtract(dataPleasePleaseMe); // alternativa
Console.WriteLine(tempoPassato.TotalDays + " <= giorni passati");
Console.WriteLine((tempoPassato.TotalDays / 365) + " <= anni passati");

LogTitolo("Comparazione date");
Console.WriteLine(dataPleasePleaseMe == dataLetItBe);
Console.WriteLine(dataPleasePleaseMe > dataLetItBe);
Console.WriteLine(dataPleasePleaseMe < dataLetItBe);

var data1 = DateTimeOffset.FromUnixTimeSeconds(1646732617);
var data2 = DateTimeOffset.FromUnixTimeSeconds(1646735617);
Console.WriteLine(data1);
Console.WriteLine(data2);
Console.WriteLine(data1 == data2);
Console.WriteLine(data1.Date == data2.Date);
