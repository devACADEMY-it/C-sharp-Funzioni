﻿using System.Text.Json;
using System.Text.Json.Serialization;

// 05-01 INTRODUZIONE
void LogTitolo(string titolo)
{
    Console.WriteLine("");
    Console.ForegroundColor = ConsoleColor.DarkGreen;
    Console.WriteLine(titolo + ":");
    Console.ResetColor();
}

// 05-02 LEGGERE CONTENUTO DI UNA CARTELLA
// directory corrente
var root = Directory.GetCurrentDirectory();
LogTitolo("root");
Console.WriteLine(root);

// informazioni sulla directory
var rootInfo = new DirectoryInfo(root);
LogTitolo("rootInfo.FullName");
Console.WriteLine(rootInfo.FullName);
LogTitolo("rootInfo.Parent:");
Console.WriteLine(rootInfo.Parent);

string[] dirs = Directory.GetDirectories(root); // path assoluto torna risultati assoluti
// dirs = Directory.GetDirectories(rootInfo.FullName); // equivalente

// dirs = Directory.GetDirectories("documenti"); // path relativo torna risultati relativi
// dirs = Directory.GetDirectories("documenti", "prev*", SearchOption.AllDirectories); 

LogTitolo("Lista directories");
Console.WriteLine(string.Join("\n", dirs));

// 05-03 INFORMAZIONI CARTELLA
var dirsInfo = rootInfo.GetDirectories(); // se parto da un Info ottengo altri info
LogTitolo("Lista directories DirectoryInfo");
// Console.WriteLine(string.Join("\n", dirsInfo.Select((s) =>
// {
//     return s.FullName;
// })));

Console.WriteLine(string.Join("\n", dirsInfo.Select(s => s.FullName)));

// 05-04 FILES
var files = Directory.GetFiles(Path.Combine("documenti", "fatture", "2021"));
// files = Directory.GetFiles("documenti", "*.pdf", SearchOption.AllDirectories);
LogTitolo("Lista files");
Console.WriteLine(string.Join("\n", files));

var filesInfo = rootInfo.GetFiles("*.pdf", SearchOption.AllDirectories); // se parto da un Info ottengo altri info
LogTitolo("Lista files FileInfo");
Console.WriteLine(string.Join("\n", filesInfo.Select(s => s.CreationTime + " " + s.FullName)));

// 05-05 LETTURA FILE
var filePath = Path.Combine("documenti", "preventivi", "todo.txt");

LogTitolo("Lettura file di testo");
Console.Write(File.ReadAllText(filePath));

var righe = File.ReadAllLines(filePath);
LogTitolo("Lettura file di testo riga per riga");

var numeroRiga = 1;
foreach (var riga in righe)
{
    Console.WriteLine(numeroRiga + " - " + riga);
    numeroRiga++;
}

var filePathJson = Path.Combine("documenti", "preventivi", "data.json");

LogTitolo("Lettura file json");
Console.Write(File.ReadAllText(filePathJson));

// 05-06 SCRITTURA FILE
// se non esiste il file viene creato, altrimenti sovrascritto
var fileDaScriverePath = @"C:\Progetti\devACADEMY\C# Funzioni\cs-funzioni\documenti\preventivi\note.txt";

string[] righeDaScrivere = { "Nota 1", "Nota 2", "Nota 3" };
File.WriteAllLines(fileDaScriverePath, righeDaScrivere);

// sovrascrive
string[] righeDaSovraScrivere = { "Nota 01", "Nota 02", "Nota 03" };
File.WriteAllLines(fileDaScriverePath, righeDaSovraScrivere);

// append
StreamWriter file = new StreamWriter(fileDaScriverePath, append: true);
file.WriteLine("Nota 04");
file.Close(); // se non lo chiudo rimane in uso e nessunaltro può accedervi

// alternativa 1
using (StreamWriter f = new StreamWriter(fileDaScriverePath, append: true))
{
    f.WriteLine("Nota 05");
}

// alternativa 2
using StreamWriter f2 = new StreamWriter(fileDaScriverePath, append: true);
f2.WriteLine("Nota 06");

// 05-07 SPOSTARE, COPIARE, ELIMINARE FILES
string fileName = "f1.pdf";
string cartellaSorgente = Path.Combine("documenti", "fatture", "2021");
string cartellaDestinazione = Path.Combine("documenti", "fatture", "2022");

// creazione directory se non esiste
if (!Directory.Exists(cartellaDestinazione))
{
    Directory.CreateDirectory(cartellaDestinazione);
}

var fileSorgete = Path.Combine(cartellaSorgente, fileName);
var fileDestinazione = Path.Combine(cartellaDestinazione, fileName);
if (File.Exists(fileSorgete) && !File.Exists(fileDestinazione))
{
    File.Copy(fileSorgete, fileDestinazione);
}

fileSorgete = Path.Combine(cartellaSorgente, "f2.pdf");
fileDestinazione = Path.Combine(cartellaDestinazione, "f2.pdf");
if (File.Exists(fileSorgete))
{
    File.Move(fileSorgete, fileDestinazione, true);
}

File.Delete(fileDestinazione);

fileDestinazione = Path.Combine(cartellaDestinazione, "f1.pdf");
var fi = new FileInfo(fileDestinazione);
fi.Delete(); // fi.CopyTo(); e fi.MoveTo();

// 05-08 SERIALIZZAZIONE JSON
// aggiungi using
// using System.Text.Json;
// using System.Text.Json.Serialization;
List<string> listaDaSerializzare = new List<string>() { "da", "una", "lacrima", "sul", "viso" };
var options = new JsonSerializerOptions { WriteIndented = true };
string stringaJson = JsonSerializer.Serialize(listaDaSerializzare, options);

var filePathDaSerializzare = "lista.json";
File.WriteAllText(Path.Combine("documenti", filePathDaSerializzare), stringaJson);

var stringaJsonLetta = File.ReadAllText(Path.Combine("documenti", filePathDaSerializzare));
var listaRecuperata = JsonSerializer.Deserialize<List<string>>(stringaJsonLetta);

LogTitolo("Lista deserializzata");
Console.WriteLine(string.Join("\n", listaRecuperata!.ToArray()));