﻿/*
CALCOLATRICE
1. Dichiarare una funzione "somma" che accetti come parametro un numero variabile di double
2. La funzione deve ritornare una List di double
   che sia il risultato della somma dei double passati come parametro: n + (n + 1) escludendo l'ultimo elemento
   es. in [2,5,6,9] => out [(2+5),(5+6),(6+9)] => [7,11,15]
3. Creare altre 3 funzione come "somma": sottrazione, moltiplicazione, divisione
4. Dichiarare una funzione "calcola" che accetti come parametro un numero variabile di double
   e una stringa col tipo di operazione da eseguire
5. In base all'operazione specificata eseguire la funzione corrispondendente (somma, sottrazione, moltiplicazione, divisione)
   e ritornarne il risultato
6. Creare una funzione "logga" che prenda come paramtro il risultato di cui sopra
   e logghi ogni elemento del risultato su una riga della console
*/
