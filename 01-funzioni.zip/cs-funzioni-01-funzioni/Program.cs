﻿// 01-01 INTRODUZIONE E SINTASSI
// le funzioni ci permettono di isolare delle porzioni di codice per poterle riutilizzare
// essendo questo lo scopo, una funzione è utile se possiamo riutilizzarla più volte
void Saluta()
{
    Console.WriteLine("Scrivi l'ora corrente");
    Console.WriteLine($"Ciao, sono le {DateTime.Now}");
    Thread.Sleep(1000);
}

Saluta();

for (int i = 0; i < 4; i++)
{
    Saluta();
}

// 01-02 VALORI DI RITORNO
string RitornaUnSaluto()
{
    return $"Ciao, sono le {DateTime.Now}";
}
for (int i = 0; i < 4; i++)
{
    string saluto = RitornaUnSaluto();
    Console.WriteLine(saluto);

    // Console.WriteLine(RitornaUnSaluto());
    Thread.Sleep(1000);

}

int TiraUnDado()
{
    Random rnd = new Random();

    int numero = rnd.Next(1, 7);
    return numero;
}

for (int i = 0; i < 40; i++)
{
    // Console.WriteLine(TiraUnDado());

    int risultato = TiraUnDado();
    Console.WriteLine($"Numero random: {risultato}");
}

// 01-03 TUPLE
// le tuple forniscono una sintassi concisa per raggruppare dati
(int, int) tupla = (3, 7);
var tupla2 = (4, 9.5m);
Console.WriteLine($"Valore {tupla2.Item2} di tipo {tupla2.Item2.GetType()}");

(int, int) TiraDueDadi()
{
    Random rnd = new Random();

    int n1 = rnd.Next(1, 7);
    int n2 = rnd.Next(1, 7);

    return (n1, n2);
}

var r = TiraDueDadi();
Console.WriteLine($"Risultato: {r}");
Console.WriteLine($"Numero 1: {r.Item1}");
Console.WriteLine($"Numero 2: {r.Item2}");

(int n1, int n2) TiraDueDadiConNome()
{
    Random rnd = new Random();

    int numero1 = rnd.Next(1, 7);
    int numero2 = rnd.Next(1, 7);

    return (n1: numero1, n2: numero2);
}

var rn = TiraDueDadiConNome();
Console.WriteLine($"Risultato: {rn}");
Console.WriteLine($"Numero 1: {rn.n1}");
Console.WriteLine($"Numero 2: {rn.n2}");

