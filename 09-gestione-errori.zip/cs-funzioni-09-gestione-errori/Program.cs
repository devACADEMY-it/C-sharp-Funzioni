﻿void LogTitolo(string titolo)
{
    Console.WriteLine("");
    Console.ForegroundColor = ConsoleColor.DarkGreen;
    Console.WriteLine(titolo + ":");
    Console.ResetColor();
}

// 09-01 ECCEZIONI
// La gestione degli errori in C# è fatta attraverso le eccezioni
// Le eccezioni forniscono un metodo strutturato per gestire le condizioni di errore a livello di sistema e a livello di applicazione. 
// Un'eccezione viene generata in due modi diversi:
// 1. Da determinate condizioni eccezionali che si verificano durante l'elaborazione di istruzioni e espressioni C#, 
//    quando appunto queste operazioni non può essere completata normalmente. 
// 2. Attraverso un'istruzione throw che genera un'eccezione immediatamente e in modo non condizionale.
//    Il codice si ferma e non raggiunge mai l'istruzione immediatamente successiva a throw
// Tutte le eccezioni derivano da System.Exception (sono anche System.Exception) come ogni tipo è anche System.Object

LogTitolo("Eccezioni comuni di sistema");

var n = 2;
var m = 0;

// Console.WriteLine("Divisione per zero");
// Console.WriteLine(n / m);

var animali = new string[] { "cane", "gatto" };

// Console.WriteLine("Indice oltre in range");
// Console.WriteLine(animali[8]);

// Console.WriteLine("File non trovato");
// var text = File.ReadAllText("test.pdf");

// Console.WriteLine("Formato non corretto");
// int quattro = int.Parse("");

// Console.WriteLine("Riferimento nullo");
// object o2 = null;
// int i2 = (int)o2;


// 09-02 IL COSTRUTTO TRY/CATCH 
LogTitolo("Costrutto Try / Catch / Finally");
try
{
    var risultato = n / m;
}
catch (Exception ex) // tipo da intercettare
{
    // blocco eseguito solo se c'è stato il tipo di eccezzione catchato
    Console.WriteLine(ex.Message);
}
finally
{
    // blocco eseguito comunque anche se c'è stato un errore
    Console.WriteLine("Eseguito anche se c'è stata un'eccezione.");
}

// configurazioni possibili

LogTitolo("Costrutto Try / Catch");
try
{
    var risultato = n / m;
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}

LogTitolo("Costrutto Try / Finally");
try
{
    // var risultato = n / m;
}
finally
{
    Console.WriteLine("Raggiunta fine blocco");
}

// 09-03 CATCH MULTIPLI
// try / catch * n / finally
// È importante posizionare prima i blocchi catch con le classi di eccezione più specifiche
// e poi quelle più generiche
// poichè viene eseguioto UN SOLO blocco catch, quello più pertinente secondo il tipo e l'ordine
LogTitolo("try / catch * n / finally");
StreamReader? file = null;
try
{
    file = new StreamReader("test.txt");

    // TODO: creo file test.txt vuoto
    var testo = file.ReadLine();

    // TODO: aggiungo la stringa "zero" al testo del file

    // TODO: aggiungo il numero 0 al testo del file
    var numero = int.Parse(testo);

    // TODO: cambio il numero 0 nel file
    var risultato = n / numero;
}
catch (FileNotFoundException ex)
{
    Console.WriteLine("File non trovato");
    Console.WriteLine(ex.Message);
}
catch (ArgumentNullException ex)
{
    Console.WriteLine("Argomento nullo");
    Console.WriteLine(ex.Message);
}
catch (FormatException ex)
{
    Console.WriteLine("Formato non corretto");
    Console.WriteLine(ex.Message);
}
catch (DivideByZeroException ex)
{
    Console.WriteLine("Divisione per zero");
    Console.WriteLine(ex.Message);
}
catch (Exception ex)
{
    Console.WriteLine("Exception non gestita, vedi sotto.");
    Console.WriteLine(ex.GetType());
    Console.WriteLine(ex.Message);
}
finally
{
    file?.Close();
    Console.WriteLine("Finally: File chiuso.");
}

// 09-04 THROW ED ECCEZIONI CUSTOM
LogTitolo("Eccezioni custom");
var anni = 17;

if (anni > 18)
{
    Console.WriteLine($"Ha la patente di guida da {anni - 18} anno");
}
else
{
    throw new Exception("Non ha la patente!");
}

LogTitolo("Throw");
void CalcolaAnniPatente(int? anni)
{
    if (!anni.HasValue)
    {
        throw new NullReferenceException("Specificare gli anni.");
    }

    if (anni < 18)
        throw new Exception("Non ha la patente!");

    Console.WriteLine($"Ha la patente di guida da {anni - 18} anni");
}

int? eta = null;

try
{
    CalcolaAnniPatente(eta);
}
catch (NullReferenceException ex)
{
    Console.WriteLine("Eccezione null gestita");
    Console.WriteLine(ex.Message);
}
catch (Exception ex)
{
    Console.WriteLine("Eccezione gestita");
    Console.WriteLine(ex.Message);
}

