﻿// 03-01 FUNZIONI RICORSIVE
void ScriviPrimaLettera(string nome)
{
    if (nome.Length > 0)
    {
        Console.WriteLine(nome.Substring(0, 1).ToUpper()); // scrivo la prima lettera
        ScriviPrimaLettera(nome.Substring(1)); // richiamo la funzione con la stessa stringa meno la orima lettera
    }
}

ScriviPrimaLettera("giovanni");

// 03-02 LAMBDA
// Usare un'espressione lambda per creare una funzione anonima.
// action (non ritorna un valore)
// func (ritorna un valore)
Console.WriteLine("*** LAMBDA ***");
List<int> numeri = new List<int> { 1, 2, 3, 4 };

numeri.ForEach(x =>
{
    Console.WriteLine(x * x);
});

// var quadrati = numeri.Select(x =>
// {
//     return x * x;
// });
var quadrati = numeri.Select(x => x * x);
Console.WriteLine($"quadrati: {quadrati.ToArray()[1]}");

int Quadrato(int x)
{
    return x * x;
}

var quadrati2 = numeri.Select(x => Quadrato(x));
Console.WriteLine($"quadrati: {quadrati2.ToArray()[2]}");

// 03-03 LAMBDA E TUPLE
List<(int, int)> tuples = new List<(int, int)> { (3, 4), (5, 6), (7, 8) };
var somme = tuples.Select(x => x.Item1 + x.Item2);
Console.WriteLine(somme.ToArray()[2]);
