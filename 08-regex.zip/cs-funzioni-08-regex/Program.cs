﻿using System.Text.RegularExpressions;

void LogTitolo(string titolo)
{
    Console.WriteLine("");
    Console.ForegroundColor = ConsoleColor.DarkGreen;
    Console.WriteLine(titolo + ":");
    Console.ResetColor();
}

// 08-01 INTRODUZIONE
// metodo efficace e flessibile per elaborare del testo
// ricerca e modifica
// regex => regular expressions
// si basano su pattern (scritti con una sintassi particolare)
// carattere @ per evitare di fare l'escape della stringa


string pattern = @"\d+";
// \d = carattere numerico
// + = 1 o più del precedente
string s = "Ciao, sono Gigi e ho 27 anni. Sono alto 183 cm.";

LogTitolo("Esiste almeno un match (corrispondenza)?");
if (Regex.IsMatch(s, pattern))
{
    Console.WriteLine($"Nella stringa '{s}' è presente almeno un numero.");
}
else
{
    Console.WriteLine($"Nella stringa '{s}' non ci sono numeri.");
}

pattern = @"\d+";
s = "Ciao, sono Gigi.";
if (Regex.IsMatch(s, pattern))
{
    Console.WriteLine($"Nella stringa '{s}' è presente almeno un numero.");
}
else
{
    Console.WriteLine($"Nella stringa '{s}' non ci sono numeri.");
}

pattern = @"^\d+$";
// ^ = inizio stringa
// $ = fine stringa
s = "123";
if (Regex.IsMatch(s, pattern))
{
    Console.WriteLine($"Nella stringa '{s}' sono presenti solo numeri.");
}

// 08-02 ESTRAPOLAZIONE CORRISPONDENZE
LogTitolo("Estrapolare le corrispondenze");
s = "Ciao, sono Gigi e ho 27 anni. Sono alto 183 cm.";
pattern = @"\d+";
var m = Regex.Match(s, pattern); // torna la prima corrispondenza

// prima
if (m.Success)
{
    Console.WriteLine($"Nella stringa '{s}' il primo numero trovato è {m.Value}.");
}
Console.WriteLine();

// NextMatch
while (m.Success)
{
    Console.WriteLine($"Nella stringa '{s}' ho trovato il numero {m.Value}.");
    m = m.NextMatch();
}
Console.WriteLine();

// tutte + ciclo
foreach (Match c in Regex.Matches(s, pattern))
{
    Console.WriteLine($"Nella stringa '{s}' ho trovato il numero {c.Value} all'indice {c.Index}");
}

// 08-03 SOSTITUZIONE E SPLIT
// sostituazione
LogTitolo("Sostituire le corrispondenze");
Console.WriteLine(Regex.Replace(s, pattern, "XX"));

// split
LogTitolo("Separare in base alla corrispondenza");
s = "1. Uova 2. Pane 3. Latte 4. Yogurt 5. Banane";
pattern = @"\b\d{1,2}\.\s";
foreach (string item in Regex.Split(s, pattern))
{
    if (!string.IsNullOrEmpty(item))
    {
        Console.WriteLine(item);
    }
}

// 08-04 GRUPPI
LogTitolo("Trovare corrispondenze e raggrupparle");
pattern = @"\b(\d{1,2})\s+(\w+)\s+(\d{4})\b";
// \b	= Inizia la corrispondenza sul confine di parola.
// (\d{1,2}) = Trova la corrispondenza con una o due cifre decimali. Equivale al primo gruppo di acquisizione.
// \s+ = Trova la corrispondenza con uno o più spazi vuoti
// (\w+) = Trova la corrispondenza di uno o più caratteri alfanumerici. Equivale al secondo gruppo di acquisizione.
// (\d{4}) = Trova la corrispondenza di 4 cifre decimali. Equivale al terzo gruppo di acquisizione.
// \b = Termina la corrispondenza sul confine di parola.
s = "Nato: 28 Luglio 1989";
Match match = Regex.Match(s, pattern);
if (match.Success)
{
    for (int i = 0; i < match.Groups.Count; i++)
    {
        Console.WriteLine($"Group {i}: {match.Groups[i].Value}");
    }
}

pattern = @"(\d{1,2}).+(\d{3})\s*cm";
// .+ = Trova almeno 1 di qualsiasi carattere
// \s* = Trova 0 o pià spazi bianchi
// cm = Trova i caratteri "cm"
s = "Ciao, sono Gigi e ho 27 anni. Sono alto 183 cm.";
match = Regex.Match(s, pattern);
if (match.Success)
{
    for (int ctr = 0; ctr < match.Groups.Count; ctr++)
    {
        Console.WriteLine($"Group {ctr}: {match.Groups[ctr].Value}");
    }
}

pattern = @"(?<anni>\d{1,2}).+(?<altezza>\d{3})\s*cm";
// .+ = Trova almeno 1 di qualsiasi carattere
// \s* = Trova 0 o pià spazi bianchi
// cm = Trova i caratteri "cm"
s = "Ciao, sono Gigi e ho 27 anni. Sono alto 183 cm.";
match = Regex.Match(s, pattern);
if (match.Success)
{
    var grAnni = match.Groups["anni"];
    var grAltezza = match.Groups["altezza"];
    Console.WriteLine($"Gruppo {grAnni.Name}: {grAnni.Value}");
    Console.WriteLine($"Gruppo {grAltezza.Name}: {grAltezza.Value}");
}

// 08-05 ESEMPIO RIEPILOGATIVO
LogTitolo("Estrapolazione dati");
pattern = @"([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)";
s = File.ReadAllText("users.json");

var emails = Regex.Matches(s, pattern);
Console.WriteLine($"Trovate {emails.Count} email");
foreach (Match item in emails)
{
    Console.WriteLine(item.Value.ToLower());
}
Console.WriteLine();

pattern = @"\d{5}-\d{4}";
var zip = Regex.Matches(s, pattern);
Console.WriteLine($"Trovati {zip.Count} zipcodes");
foreach (Match item in zip)
{
    Console.WriteLine(item.Value.ToLower());
}
