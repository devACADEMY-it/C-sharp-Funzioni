﻿// 02-01 DEFINIZIONE PARAMETRI
int AggiungiUno(int numero)
{
    return numero + 1;
}

Console.WriteLine($"Aggiungi 1: {AggiungiUno(3)}");

int Somma(int addendo1, int addendo2)
{
    return addendo1 + addendo2;
}
Console.WriteLine($"Somma: {Somma(3, 5)}");

// con parametri nominati (comodo quando sono molti e non vogliamo andare in ordine)
Console.WriteLine($"Somma: {Somma(addendo2: 5, addendo1: 3)}");

string PariODispari(int n)
{
    if (n % 2 == 0)
    {
        return $"{n} è PARI";
    }
    else
    {
        return $"{n} è DISPARI";
    }
}

Console.WriteLine(PariODispari(5));

// 02-02 PARAMETRI VALORE O RIFERIMENTO
// C# passa i parametri come valore di default
// cioè passa una copia della variabile

void quadratoByVal(int valParameter)
{
    valParameter *= valParameter;
}

int numero = 4;
quadratoByVal(numero);
Console.WriteLine("val");
Console.WriteLine(numero);

// ref passa un riferimento ad una variabile
// (DEVE essere inizializzata prima di passarla alla funzione)
void quadratoByRef(ref int refParameter)
{
    refParameter *= refParameter;
}

quadratoByRef(ref numero);
Console.WriteLine("ref");
Console.WriteLine(numero);

// out passa un riferimento ad una variabile
// (NON DEVE essere inizializzata prima di passarla alla funzione)
void ArgomentoOut(out int numero)
{
    numero = 44;
}

int inizializzataNellaFunzione;
ArgomentoOut(out inizializzataNellaFunzione);
Console.WriteLine("out");
Console.WriteLine(inizializzataNellaFunzione);

// 02-03 NUMERO DI PARAMETRI VARIABILE E VALORI DI DEFAULT
int SommaTutto(params int[] numeri)
{
    int r = 0;
    foreach (var n in numeri)
    {
        r += n;
    }

    return r;
}

int[] numeriDaSommare = { 1, 2, 3, 4 };
Console.WriteLine($"Array da sommare: {SommaTutto(numeriDaSommare)}");
Console.WriteLine($"Parametri separati da sommare: {SommaTutto(3, 6, 7, 9, 56)}");

// In una dichiarazione di metodo non è possibile aggiungere altri parametri dopo la parola chiave params ed è consentito l'uso di una sola parola chiave params.
string SommaTuttoESaluta(string nome, string cognome, params int[] numeri)
{
    int r = 0;
    foreach (var n in numeri)
    {
        r += n;
    }

    return $"Ciao {nome} {cognome}, la somma è {r}.";
}
Console.WriteLine(SommaTuttoESaluta("Gigi", "Rame", 3, 6, 7, 9, 56));

// i valori di default (parametri facoltativi) devono essere definiti per ultimi
void SalutaNVolte(string nome, string saluto = "Ciao", int volte = 3)
{
    for (int i = 0; i < volte; i++)
    {
        Console.WriteLine($"{saluto} {nome} ({i + 1})");
    }
}

SalutaNVolte("Bruno");
SalutaNVolte("Giorgio", "Salve", 6);